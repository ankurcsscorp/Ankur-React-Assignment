import React from "react";
import "./Style.css";
const Footer = () => {
  return <div className="FooterSection">Footer</div>;
};

export default Footer;
