import React from "react";
import "./Style.css";
const MainSection = () => {
  return <div className="mainSection">MainSection</div>;
};

export default MainSection;
