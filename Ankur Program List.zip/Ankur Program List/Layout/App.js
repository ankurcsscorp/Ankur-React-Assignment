import React, { useEffect } from "react";
import "./App.css";
import Footer from "./Components/Footer";
import Header from "./Components/Header";
import MainSection from "./Components/MainSection";
import SideBar from "./Components/SideBar";
function App() {
  useEffect(() => {
    document.body.style.backgroundColor = "#979797";
  }, []);
  return (
    <div className="App">
      <Header />
      <SideBar />
      <MainSection />
      <Footer />
    </div>
  );
}

export default App;
