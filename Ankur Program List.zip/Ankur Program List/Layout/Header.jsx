import React from "react";
import "./Style.css";
const Header = () => {
  return (
    <div className="Header">
      <li className="HeaderList">Logo</li>
      <li className="HeaderList">
        <a href="#">Logout</a>
      </li>
    </div>
  );
};

export default Header;
