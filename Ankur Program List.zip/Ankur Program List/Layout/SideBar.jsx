import React from "react";
import "./Style.css";
const SideBar = () => {
  return (
    <div className="MainSideBar">
      <ul>
        <li className="SideBarList">SideBar 1</li>
        <li className="SideBarList">SideBar 2</li>
        <li className="SideBarList">SideBar 3</li>
        <li className="SideBarList">SideBar 4</li>
        <li className="SideBarList">SideBar 5</li>
      </ul>
    </div>
  );
};

export default SideBar;
