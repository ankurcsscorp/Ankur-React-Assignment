import React from "react";
import "./App.css";
import BasicTable from "./Table/BasicTable";

function App() {
  return (
    <div className="App">
      <BasicTable />
    </div>
  );
}

export default App;
