import React from "react";
import { useTable } from "react-table";
const Table = () => {
  return <div>Table</div>;
};

export default Table;
