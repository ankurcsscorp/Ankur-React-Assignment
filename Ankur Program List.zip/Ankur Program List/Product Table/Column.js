export const COLUMNS = [
  {
    Header: "Brand",
    accessor: "Brand_Name",
  },
  {
    Header: "Model",
    accessor: "Modal_Name",
  },
  {
    Header: "Body Style",
    accessor: "BodyStyle",
  },
  {
    Header: "Varient",
    accessor: "Varient_Name",
  },
  {
    Header: "Price",
    accessor: "Car_Price",
  },
];
