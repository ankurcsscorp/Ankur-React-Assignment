const firstFunction = (person) => {
  let ageType = "";
  let name = person.firstname.charAt(0) + person.lastname.charAt(0);
  let birthday = new Date(person.birthday).getFullYear();
  let currentYear = new Date().getFullYear();
  let age = currentYear - birthday;
  if (age > 60) {
    ageType = "Senior";
  } else if (age >= 20 && age <= 59) {
    ageType = "Adult";
  } else if (age >= 13 && age <= 19) {
    ageType = "Teen";
  } else if (age > 0 && age <= 12) {
    ageType = "Young";
  }
  console.log("Initials: " + name, ", Age: ", age, ageType);
};

const person = {
  firstname: "Juan",
  lastname: "Dela Cruz",
  birthday: "01/01/2000",
};
firstFunction(person);
